import asyncio
import logging
import os
import sqlite3
from decimal import Decimal, InvalidOperation

import aiohttp
from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command, CommandStart
from aiogram.types import Message, CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder
from dotenv import load_dotenv

load_dotenv()
BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
CRYPTOPAY_TOKEN = os.getenv("CRYPTOPAY_TOKEN", "").strip()
ADMIN_ID = int(os.getenv("ADMIN_ID", "0"))
DB_PATH = os.getenv("DB_PATH", "shop.db")
ASSET = os.getenv("CRYPTOPAY_ASSET", "USDT").upper()
CRYPTOPAY_API = "https://pay.crypt.bot/api"

logging.basicConfig(level=logging.INFO)
dp = Dispatcher()


def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with db() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT NOT NULL DEFAULT '',
            price TEXT NOT NULL,
            active INTEGER NOT NULL DEFAULT 1
        )""")
        con.execute("""CREATE TABLE IF NOT EXISTS cart (
            user_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            quantity INTEGER NOT NULL DEFAULT 1,
            PRIMARY KEY (user_id, product_id)
        )""")
        con.execute("""CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            username TEXT,
            items TEXT NOT NULL,
            amount TEXT NOT NULL,
            invoice_id TEXT,
            pay_url TEXT,
            status TEXT NOT NULL DEFAULT 'pending',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )""")


def is_admin(user_id: int) -> bool:
    return ADMIN_ID != 0 and user_id == ADMIN_ID


def main_menu():
    kb = InlineKeyboardBuilder()
    kb.button(text="🛍 Каталог", callback_data="catalog")
    kb.button(text="🛒 Кошик", callback_data="cart")
    kb.button(text="ℹ️ Допомога", callback_data="help")
    kb.adjust(2, 1)
    return kb.as_markup()


def catalog_keyboard():
    kb = InlineKeyboardBuilder()
    with db() as con:
        products = con.execute(
            "SELECT id, name, price FROM products WHERE active=1 ORDER BY id DESC"
        ).fetchall()
    for p in products:
        kb.button(text=f"{p['name']} — {p['price']} {ASSET}", callback_data=f"product:{p['id']}")
    kb.button(text="🛒 Переглянути кошик", callback_data="cart")
    kb.button(text="⬅️ Головне меню", callback_data="home")
    kb.adjust(1)
    return kb.as_markup()


async def crypto_api(method: str, payload: dict):
    if not CRYPTOPAY_TOKEN:
        raise RuntimeError("Не задано CRYPTOPAY_TOKEN у файлі .env")
    headers = {"Crypto-Pay-API-Token": CRYPTOPAY_TOKEN}
    timeout = aiohttp.ClientTimeout(total=20)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        async with session.post(
            f"{CRYPTOPAY_API}/{method}", headers=headers, json=payload
        ) as response:
            data = await response.json(content_type=None)
            if response.status != 200 or not data.get("ok"):
                raise RuntimeError(f"Crypto Pay API помилка: {data}")
            return data["result"]


@dp.message(CommandStart())
async def start(message: Message):
    await message.answer(
        "Вітаємо в магазині! 👋\n\n"
        "Обирай товари в каталозі, додавай їх у кошик та сплачуй криптовалютою.",
        reply_markup=main_menu()
    )


@dp.message(Command("help"))
async def help_cmd(message: Message):
    text = (
        "🛍 Як зробити замовлення:\n"
        "1. Відкрий «Каталог».\n"
        "2. Обери товар і натисни «Додати в кошик».\n"
        "3. Відкрий кошик і натисни «Оформити замовлення».\n"
        "4. Сплати рахунок та натисни «Перевірити оплату».\n\n"
        "Адмін-команди: /addproduct, /products_admin, /orders, /deleteproduct."
    )
    await message.answer(text, reply_markup=main_menu())


@dp.callback_query(F.data == "home")
async def home(call: CallbackQuery):
    await call.message.edit_text("Головне меню магазину:", reply_markup=main_menu())
    await call.answer()


@dp.callback_query(F.data == "help")
async def help_callback(call: CallbackQuery):
    await call.message.answer(
        "🛍 Обери «Каталог», щоб переглянути товари.\n"
        "Додай товари в кошик, а потім оформи замовлення.\n"
        "Оплата проходить через Crypto Pay."
    )
    await call.answer()


@dp.callback_query(F.data == "catalog")
async def catalog(call: CallbackQuery):
    with db() as con:
        count = con.execute("SELECT COUNT(*) FROM products WHERE active=1").fetchone()[0]
    if not count:
        await call.message.edit_text(
            "Каталог поки порожній. Завітай трохи пізніше 🙂",
            reply_markup=main_menu()
        )
    else:
        await call.message.edit_text("🛍 Каталог товарів:", reply_markup=catalog_keyboard())
    await call.answer()


@dp.callback_query(F.data.startswith("product:"))
async def product_detail(call: CallbackQuery):
    product_id = int(call.data.split(":")[1])
    with db() as con:
        p = con.execute("SELECT * FROM products WHERE id=? AND active=1", (product_id,)).fetchone()
    if not p:
        await call.answer("Товар не знайдено.", show_alert=True)
        return
    kb = InlineKeyboardBuilder()
    kb.button(text="➕ Додати в кошик", callback_data=f"add:{product_id}")
    kb.button(text="🛒 Кошик", callback_data="cart")
    kb.button(text="⬅️ До каталогу", callback_data="catalog")
    kb.adjust(1)
    await call.message.edit_text(
        f"📦 <b>{p['name']}</b>\n\n{p['description']}\n\n"
        f"💰 Ціна: <b>{p['price']} {ASSET}</b>",
        reply_markup=kb.as_markup(),
        parse_mode="HTML"
    )
    await call.answer()


@dp.callback_query(F.data.startswith("add:"))
async def add_to_cart(call: CallbackQuery):
    product_id = int(call.data.split(":")[1])
    with db() as con:
        exists = con.execute("SELECT id FROM products WHERE id=? AND active=1", (product_id,)).fetchone()
        if not exists:
            await call.answer("Цього товару вже немає.", show_alert=True)
            return
        con.execute(
            """INSERT INTO cart(user_id, product_id, quantity) VALUES(?,?,1)
               ON CONFLICT(user_id, product_id) DO UPDATE SET quantity=quantity+1""",
            (call.from_user.id, product_id)
        )
    await call.answer("Додано в кошик ✅")
    await call.message.answer("Товар додано. Продовжуй покупки або відкрий кошик.", reply_markup=main_menu())


def get_cart(user_id: int):
    with db() as con:
        return con.execute("""
            SELECT p.id, p.name, p.price, c.quantity
            FROM cart c JOIN products p ON p.id=c.product_id
            WHERE c.user_id=? AND p.active=1 ORDER BY p.id
        """, (user_id,)).fetchall()


@dp.callback_query(F.data == "cart")
async def show_cart(call: CallbackQuery):
    items = get_cart(call.from_user.id)
    if not items:
        await call.message.edit_text("🛒 Кошик порожній.", reply_markup=main_menu())
        await call.answer()
        return
    total = Decimal("0")
    lines = ["🛒 <b>Твій кошик</b>\n"]
    for item in items:
        line_total = Decimal(item["price"]) * item["quantity"]
        total += line_total
        lines.append(
            f"• {item['name']} × {item['quantity']} — "
            f"{line_total.normalize()} {ASSET}"
        )
    lines.append(f"\n💰 <b>Разом: {total.normalize()} {ASSET}</b>")
    kb = InlineKeyboardBuilder()
    kb.button(text="💳 Оформити замовлення", callback_data="checkout")
    kb.button(text="🗑 Очистити кошик", callback_data="clearcart")
    kb.button(text="⬅️ До каталогу", callback_data="catalog")
    kb.adjust(1)
    await call.message.edit_text("\n".join(lines), reply_markup=kb.as_markup(), parse_mode="HTML")
    await call.answer()


@dp.callback_query(F.data == "clearcart")
async def clear_cart(call: CallbackQuery):
    with db() as con:
        con.execute("DELETE FROM cart WHERE user_id=?", (call.from_user.id,))
    await call.message.edit_text("Кошик очищено.", reply_markup=main_menu())
    await call.answer()


@dp.callback_query(F.data == "checkout")
async def checkout(call: CallbackQuery):
    items = get_cart(call.from_user.id)
    if not items:
        await call.answer("Кошик порожній.", show_alert=True)
        return
    total = sum((Decimal(i["price"]) * i["quantity"] for i in items), Decimal("0"))
    if total <= 0:
        await call.answer("Неправильна сума замовлення.", show_alert=True)
        return

    summary = "; ".join(f"{i['name']} x{i['quantity']}" for i in items)
    with db() as con:
        cur = con.execute(
            "INSERT INTO orders(user_id, username, items, amount) VALUES(?,?,?,?)",
            (call.from_user.id, call.from_user.username or "", summary, str(total))
        )
        order_id = cur.lastrowid

    try:
        invoice = await crypto_api("createInvoice", {
            "asset": ASSET,
            "amount": str(total),
            "description": f"Замовлення #{order_id}: {summary[:700]}",
            "payload": str(order_id),
            "allow_comments": False,
            "allow_anonymous": False
        })
    except Exception:
        logging.exception("Invoice creation failed")
        with db() as con:
            con.execute("UPDATE orders SET status='invoice_error' WHERE id=?", (order_id,))
        await call.message.answer(
            "Не вдалося створити рахунок. Спробуй пізніше або напиши адміністратору."
        )
        await call.answer()
        return

    invoice_id = str(invoice["invoice_id"])
    pay_url = invoice.get("bot_invoice_url") or invoice.get(" mini_app_invoice_url") or invoice.get("pay_url")
    with db() as con:
        con.execute(
            "UPDATE orders SET invoice_id=?, pay_url=? WHERE id=?",
            (invoice_id, pay_url or "", order_id)
        )
    kb = InlineKeyboardBuilder()
    if pay_url:
        kb.button(text="💰 Сплатити криптовалютою", url=pay_url)
    kb.button(text="✅ Перевірити оплату", callback_data=f"verify:{order_id}")
    kb.button(text="⬅️ Головне меню", callback_data="home")
    kb.adjust(1)
    await call.message.answer(
        f"Замовлення <b>#{order_id}</b> створено.\n"
        f"Сума: <b>{total.normalize()} {ASSET}</b>\n\n"
        "Сплати рахунок кнопкою нижче. Після оплати натисни «Перевірити оплату».",
        reply_markup=kb.as_markup(),
        parse_mode="HTML"
    )
    await call.answer()


@dp.callback_query(F.data.startswith("verify:"))
async def verify_payment(call: CallbackQuery):
    order_id = int(call.data.split(":")[1])
    with db() as con:
        order = con.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
    if not order or order["user_id"] != call.from_user.id:
        await call.answer("Замовлення не знайдено.", show_alert=True)
        return
    if order["status"] == "paid":
        await call.answer("Це замовлення вже оплачено ✅", show_alert=True)
        return
    if not order["invoice_id"]:
        await call.answer("Для цього замовлення немає рахунку.", show_alert=True)
        return
    try:
        result = await crypto_api("getInvoices", {"invoice_ids": order["invoice_id"]})
        invoices = result.get("items", [])
        invoice = next((x for x in invoices if str(x.get("invoice_id")) == order["invoice_id"]), None)
    except Exception:
        logging.exception("Invoice status check failed")
        await call.answer("Не вдалося перевірити оплату. Спробуй ще раз.", show_alert=True)
        return

    if invoice and invoice.get("status") == "paid":
        with db() as con:
            con.execute("UPDATE orders SET status='paid' WHERE id=?", (order_id,))
            con.execute("DELETE FROM cart WHERE user_id=?", (call.from_user.id,))
        await call.message.answer(
            f"Оплату підтверджено! ✅\nЗамовлення #{order_id} прийнято. Дякуємо за покупку!"
        )
        if ADMIN_ID:
            try:
                await call.bot.send_message(
                    ADMIN_ID,
                    f"💰 Оплачено замовлення #{order_id}\n"
                    f"Покупець: @{order['username'] or 'без username'} (ID {order['user_id']})\n"
                    f"Товари: {order['items']}\nСума: {order['amount']} {ASSET}"
                )
            except Exception:
                logging.exception("Could not notify admin")
        await call.answer("Оплату підтверджено ✅")
    else:
        status = invoice.get("status", "невідомий") if invoice else "рахунок не знайдено"
        await call.answer(f"Оплату ще не підтверджено. Статус: {status}", show_alert=True)


@dp.message(Command("addproduct"))
async def add_product(message: Message):
    if not is_admin(message.from_user.id):
        await message.answer("Ця команда доступна лише адміністратору.")
        return
    # Format: /addproduct Назва | Ціна_USDT | Опис
    raw = message.text.partition(" ")[2]
    parts = [p.strip() for p in raw.split("|", 2)]
    if len(parts) != 3 or not all(parts):
        await message.answer(
            "Формат:\n/addproduct Назва | Ціна | Опис\n"
            "Приклад:\n/addproduct Навушники | 12.5 | Бездротові навушники"
        )
        return
    name, price_text, description = parts
    try:
        price = Decimal(price_text.replace(",", "."))
        if price <= 0 or not price.is_finite():
            raise InvalidOperation
    except InvalidOperation:
        await message.answer("Ціна має бути додатним числом, наприклад 12.5")
        return
    with db() as con:
        cur = con.execute(
            "INSERT INTO products(name, description, price) VALUES(?,?,?)",
            (name[:100], description[:1000], str(price.normalize()))
        )
        product_id = cur.lastrowid
    await message.answer(f"Товар додано ✅ ID: {product_id}\n{name} — {price.normalize()} {ASSET}")


@dp.message(Command("products_admin"))
async def admin_products(message: Message):
    if not is_admin(message.from_user.id):
        await message.answer("Ця команда доступна лише адміністратору.")
        return
    with db() as con:
        rows = con.execute("SELECT id,name,price,active FROM products ORDER BY id DESC").fetchall()
    if not rows:
        await message.answer("Товарів поки немає.")
        return
    await message.answer("\n".join(
        f"ID {r['id']} — {r['name']} — {r['price']} {ASSET} — "
        f"{'активний' if r['active'] else 'прихований'}" for r in rows
    ))


@dp.message(Command("deleteproduct"))
async def delete_product(message: Message):
    if not is_admin(message.from_user.id):
        await message.answer("Ця команда доступна лише адміністратору.")
        return
    try:
        product_id = int(message.text.partition(" ")[2].strip())
    except ValueError:
        await message.answer("Вкажи ID товару: /deleteproduct 3")
        return
    with db() as con:
        cur = con.execute("UPDATE products SET active=0 WHERE id=?", (product_id,))
    await message.answer("Товар приховано." if cur.rowcount else "Товар з таким ID не знайдено.")


@dp.message(Command("orders"))
async def orders(message: Message):
    if not is_admin(message.from_user.id):
        await message.answer("Ця команда доступна лише адміністратору.")
        return
    with db() as con:
        rows = con.execute(
            "SELECT id,user_id,username,items,amount,status,created_at FROM orders "
            "ORDER BY id DESC LIMIT 20"
        ).fetchall()
    if not rows:
        await message.answer("Замовлень поки немає.")
        return
    lines = []
    for r in rows:
        lines.append(
            f"#{r['id']} | {r['status']} | {r['amount']} {ASSET}\n"
            f"Покупець: @{r['username'] or 'без username'} (ID {r['user_id']})\n"
            f"{r['items']}\n{r['created_at']}"
        )
    await message.answer("\n\n".join(lines))


async def main():
    if not BOT_TOKEN:
        raise RuntimeError("Додай BOT_TOKEN у файл .env")
    init_db()
    bot = Bot(token=BOT_TOKEN)
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
